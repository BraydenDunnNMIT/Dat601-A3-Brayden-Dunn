
--Spaces miscellaneous scripts such as the indexes, users and roles. 

USE master;
USE Spaces_DDL;

/* 
Testing that the foreign key constraints are working
*/ 
select * 
from 
 company c 
 join subscriber s on s.company_ID = c.Company_ID
 join account a on s.Account_ID = a.Account_ID


 --Indexes for the database

 /* 
The indexes are created and can be seen on the subscriber table,
however they wont be ran unless the DBMS determines the index as faster then is own query plan.
However, you can force the DBMS to execute the indexes for testing purposes. 
*/

 --Creates an index that gets first and last names of subscribers with an account created before 2020.
create index Index_Name_b4_2020
on Subscriber (First_Name, Last_Name) where Creation_date < '2020-01-01';




--In case index is wanted to be dropped
drop index Index_Name_b4_2020 on subscriber;

--Force execute the index
select /*+ INDEX (Subscriber Index_Name_b4_2020) */
  *
from Subscriber;

--User accounts and Roles

/*  
Creating user accounts for `Spaces` staff, the four accounts created will be
Technician, Salesperson and an Administrator and a guest account.
*/

--Creating the user accounts and roles. (the grants will be done below)

-- Creates the technician's login account and user on the database
/* 
Creates the technician's login and user that
can read and write to the database.
*/
create login TechnicianLogin with password = 'password123';
create user TechnicianUser for login TechnicianLogin;
alter role db_datareader add member TechnicianUser;
alter role db_datawriter add member TechnicianUser;
grant execute on schema::dbo to TechnicianUser;

-- Create Salesperson login and user
/* 
Creates the salesperson's login and user that
can read and write to the database.
*/
create login SalespersonLogin with password = 'password123';
create user SalespersonUser for login SalespersonLogin;
alter role db_datareader add member SalespersonUser;
alter role db_datawriter add member SalespersonUser;
grant execute on schema::dbo to SalespersonUser;

-- Create Administrator login and user
/* 
Creates an admin login and user that
has full control and access to the database.
*/
create login AdministratorLogin with password = 'password123';
create user AdministratorUser for login AdministratorLogin;
alter role db_owner add member AdministratorUser;
grant execute on schema::dbo to AdministratorUser;


--Permission grants for the users

-- Grants permissions to the salesperson role on specific tables
/*
Gives the salesperson role access to read and edit the standard_subscription table
,subscription_length table, gold_subscription, platinum and Super_Platinum tables. 
This is done so a salesperson can create a subscription entry, edit the subscribers subscription length
and give them the correct subscription tier. 
*/

-- Grant permissions on standard_subscription
grant select, update, insert, delete on dbo.standard_subscription to SalespersonUser;
-- Grant permissions on subscription_length
grant select, update, insert, delete on dbo.subscription_length to SalespersonUser;
-- Grant permissions on gold_subscription
grant select, update, insert, delete on dbo.gold_subscription to SalespersonUser;
-- Grant permissions on platinum
grant select, update, insert, delete on dbo.platinum to SalespersonUser;
-- Grant permissions on super_platinum
grant select, update, insert, delete on dbo.Super_Platinum to SalespersonUser;


/*
Gives the technician role access to read and edit the maintenance_records table,  
3D_sensor table, supplier table, and the parts table.
This is done so the service technician can create and edit the 3D sensors maintenance records, and put into
the database what part was changed and by what supplier with the total cost of the repair.
*/

-- Grant permissions on maintenance_records
grant select, update, insert, delete on dbo.maintenance_records to TechnicianUser;
-- Grant permissions on 3D_sensor
grant select, update, insert, delete on dbo.[3D_Sensor] to TechnicianUser;
-- Grant permissions on supplier
grant select, update, insert, delete on dbo.supplier to TechnicianUser;
-- Grant permissions on parts
grant select, update, insert, delete on dbo.parts to TechnicianUser;

/*
The administrator role has been given access to read and edit all tables within the database, via adding them as a part of the database owner role.
*/





























