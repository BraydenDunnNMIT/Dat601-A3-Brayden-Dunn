/*
Brayden Dunn Dat601 `Spaces` database creation script
*/

--Errors will generate when the script is run, ignore them it's just because the create tables and alter statements are in procedures.

USE master;
GO
DROP DATABASE IF EXISTS Spaces_DDL;
GO
CREATE DATABASE Spaces_DDL;
GO
USE Spaces_DDL;
GO

--	Executes must be ran separately

CREATE PROCEDURE CREATETABLES
AS
BEGIN

create table Staff (
  Staff_ID   int identity not null, 
  Position   varchar(25) null, 
  First_Name varchar(25) not null, 
  Last_Name  varchar(25) not null, 
  Phone      float(30) not null, 
  primary key (Staff_ID));

create table Company (
  Company_ID     int identity not null, 
  Staff_ID       int not null, 
  Street_Address varchar(30) not null, 
  Name           varchar(30) not null, 
  Branch         varchar(25) not null, 
  Post_Code      varchar(10) not null, 
  City           varchar(30) not null, 
  primary key (Company_ID));

create table Subscriber (
  Subscriber_ID int identity not null, 
  Account_ID    int not null, 
  Company_ID    int not null, 
  First_Name    varchar(20) not null, 
  Last_Name     varchar(20) not null, 
  [D.O.B]       date not null, 
  Creation_Date date not null, 
  primary key (Subscriber_ID));

create table Account (
  Account_ID        int identity not null, 
  Payment_ID        int not null, 
  Contract_ID       int not null, 
  Username          varchar(30) not null unique, 
  Password          varchar(30) not null, 
  Registration_Date date not null, 
  primary key (Account_ID));

create table Payment_Details (
  Payment_ID        int identity not null, 
  Purchase_Date     date not null, 
  Card_Info         varchar(60) not null, 
  Amount_Charged    float(10) null, 
  Discount_Modifier float(10) null, 
  primary key (Payment_ID));

create table Contract (
  Contract_ID           int identity not null, 
  Subscription_ID       int not null, 
  Creation_Date         date not null, 
  Contract_Description  varchar(255) null, 
  AdministratorAdmin_ID int not null, 
  primary key (Contract_ID));

create table Standard_Subscription (
  Subscription_ID        int identity not null, 
  GoldTier_ID            int not null, 
  Zone_ID                int not null, 
  Tier_ID                int not null, 
  Salesperson_ID         int not null, 
  Subscription_Length_ID int not null, 
  Subscription_Cost      float(10) not null, 
  primary key (Subscription_ID));

create table Tier (
  Tier_ID   int identity not null, 
  Tier_Type varchar(20) not null, 
  primary key (Tier_ID));

create table Zone (
  Zone_ID            int identity not null, 
  Sensor_ID          int not null, 
  Name               varchar(50) not null, 
  [Sensor#]          float(10) not null, 
  Longitude_Latitude varchar(50) not null, 
  Zone_Size          varchar(40) null, 
  primary key (Zone_ID));

create table [3D_Sensor] (
  Sensor_ID          int identity not null, 
  Data_ID            int not null, 
  Longitude_Latitude varchar(50) not null, 
  Region             varchar(20) not null, 
  Sensor_Description varchar(255) null, 
  Last_Service_Date  date null, 
  primary key (Sensor_ID));

create table Data (
  Data_ID    int identity not null, 
  [3D_Imagery] binary(500) null, 
  Audio      binary(500) null, 
  Voice      binary(500) null, 
  Altitude   varchar(50) not null, 
  primary key (Data_ID));

create table Video (
  Video_ID   int identity not null, 
  Sensor_ID  int not null, 
  [Date]     date null, 
  Video_Data binary(500) null, 
  primary key (Video_ID));

create table Maintenance_Records (
  Maintenance_ID         int identity not null, 
  TechnicianTechician_ID int not null, 
  Sensor_ID              int not null, 
  [Date]                 date not null, 
  Technician_First_Name  varchar(20) not null, 
  Technician_Last_Name   varchar(20) not null, 
  Part_Repaired          varchar(30) not null, 
  Repair_Description     varchar(255) null, 
  primary key (Maintenance_ID));

create table Supplier (
  Supplier_ID    int identity not null, 
  Parts_ID       int not null, 
  Street_Address varchar(50) not null, 
  [Phone_#]      varchar(30) not null, 
  Supplier_Name  varchar(30) not null, 
  City           varchar(30) not null, 
  Post_Code      varchar(10) not null, 
  primary key (Supplier_ID));

create table Parts (
  Part_ID       int identity not null, 
  Name          varchar(30) not null, 
  Cost          float(10) not null, 
  Purchase_Date date not null, 
  primary key (Part_ID));

create table [3D_Sensor_Supplier](
  ID          int identity not null, 
  Supplier_ID int not null, 
  Sensor_ID   int not null, 
  primary key (ID));

create table Subscription_Length(
  Subscription_Length_ID int identity not null, 
  Subscription_Start     date not null, 
  Subscription_End       date not null, 
  primary key (Subscription_Length_ID));

create table Gold_Subscription (
  GoldTier_ID int identity not null, 
  primary key (GoldTier_ID));

create table Platinum (
  PlatinumTier_ID int identity not null, 
  GoldTier_ID     int not null, 
  primary key (PlatinumTier_ID));

create table [Super_Platinum] (
  SuperPlatinumTier_ID int identity not null, 
  PlatinumTier_ID      int not null, 
  primary key (SuperPlatinumTier_ID));

create table Controls (
  ID          int identity not null, 
  GoldTier_ID int not null, 
  Video_ID    int not null, 
  primary key (ID));

create table Recieves (
  ID              int identity not null, 
  PlatinumTier_ID int not null, 
  Video_ID        int not null, 
  DataData_ID     int not null, 
  primary key (ID));

create table Owns (
  ID                   int identity not null, 
  SuperPlatinumTier_ID int not null, 
  Data_ID              int not null, 
  Video_ID             int not null, 
  primary key (ID));

create table Technician (
  Techician_ID  int identity not null, 
  StaffStaff_ID int not null, 
  Staff_ID      int not null, 
  Certification varchar(255) null, 
  primary key (Techician_ID));

create table Salesperson (
  Salesperson_ID   int identity not null, 
  MaxDiscountValue float(10) null, 
  StaffStaff_ID    int not null, 
  primary key (Salesperson_ID));

create table Administrator (
  Admin_ID      int identity not null, 
  StaffStaff_ID int not null, 
  primary key (Admin_ID));

  END;

GO
CREATE PROCEDURE ALTERTABLES
AS
BEGIN

alter table Company add constraint FKCompany577577 foreign key (Staff_ID) references Staff (Staff_ID);
alter table Subscriber add constraint FKSubscriber16016 foreign key (Company_ID) references Company (Company_ID);
alter table Subscriber add constraint FKSubscriber456032 foreign key (Account_ID) references Account (Account_ID);
alter table Account add constraint FKAccount240642 foreign key (Payment_ID) references Payment_Details (Payment_ID);
alter table Account add constraint FKAccount2178186 foreign key (Contract_ID) references Contract (Contract_ID);
alter table Contract add constraint FKContract2215061 foreign key (Subscription_ID) references Standard_Subscription (Subscription_ID);
alter table Standard_Subscription add constraint FKStandard_S274538 foreign key (Tier_ID) references Tier (Tier_ID);
alter table Standard_Subscription add constraint FKStandard_S458305 foreign key (Zone_ID) references Zone (Zone_ID);
alter table Zone add constraint FKZone2233260 foreign key (Sensor_ID) references [3D_Sensor] (Sensor_ID);
alter table [3D_Sensor] add constraint FK3D_Sensor606218 foreign key (Data_ID) references Data (Data_ID);
alter table Video add constraint FKVideo115643 foreign key (Sensor_ID) references [3D_Sensor] (Sensor_ID);
alter table Maintenance_Records add constraint FKMaintenanc190107 foreign key (Sensor_ID) references [3D_Sensor] (Sensor_ID);
alter table Supplier add constraint FKSupplier2902266 foreign key (Parts_ID) references Parts (Part_ID);
alter table [3D_Sensor_Supplier] add constraint FK3D_Sensor_204041 foreign key (Supplier_ID) references Supplier (Supplier_ID);
alter table [3D_Sensor_Supplier] add constraint FK3D_Sensor_22152 foreign key (Sensor_ID) references [3D_Sensor] (Sensor_ID);
alter table Standard_Subscription add constraint has foreign key (Subscription_Length_ID) references Subscription_Length (Subscription_Length_ID);
alter table Standard_Subscription add constraint FKStandard_S334083 foreign key (GoldTier_ID) references Gold_Subscription (GoldTier_ID);
alter table Platinum add constraint FKPlatinum219025 foreign key (GoldTier_ID) references Gold_Subscription (GoldTier_ID);
alter table [Super_Platinum] add constraint [FKSuper Plat165611] foreign key (PlatinumTier_ID) references Platinum (PlatinumTier_ID);
alter table Controls add constraint FKControls2534871 foreign key (GoldTier_ID) references Gold_Subscription (GoldTier_ID);
alter table Controls add constraint FKControls2367734 foreign key (Video_ID) references Video (Video_ID);
alter table Recieves add constraint FKRecieves2573270 foreign key (PlatinumTier_ID) references Platinum (PlatinumTier_ID);
alter table Recieves add constraint FKRecieves222909 foreign key (Video_ID) references Video (Video_ID);
alter table Owns add constraint FKOwns2205048 foreign key (SuperPlatinumTier_ID) references [Super_Platinum] (SuperPlatinumTier_ID);
alter table Owns add constraint FKOwns2465214 foreign key (Data_ID) references Data (Data_ID);
alter table Owns add constraint FKOwns2645001 foreign key (Video_ID) references Video (Video_ID);
alter table Recieves add constraint FKRecieves2831121 foreign key (DataData_ID) references Data (Data_ID);
alter table Standard_Subscription add constraint FKStandard_S195755 foreign key (Salesperson_ID) references Salesperson (Salesperson_ID);
alter table Maintenance_Records add constraint FKMaintenanc977903 foreign key (TechnicianTechician_ID) references Technician (Techician_ID);
alter table Technician add constraint FKTechnician542010 foreign key (StaffStaff_ID) references Staff (Staff_ID);
alter table Salesperson add constraint FKSalesperso863200 foreign key (StaffStaff_ID) references Staff (Staff_ID);
alter table Administrator add constraint FKAdministra844120 foreign key (StaffStaff_ID) references Staff (Staff_ID);
alter table Contract add constraint FKContract2543672 foreign key (AdministratorAdmin_ID) references Administrator(Admin_ID);

END;
go

--testing DDL script
select * from subscriber;
select * from Account;
select * from staff;

--Validating data can be inserted and is correct

exec CREATETABLES
exec ALTERTABLES
