
USE master;
USE Spaces_DDL;

-- Queries for the assessment 

--Query A

--Query B

SELECT CONCAT(SP.First_Name, ' ', SP.Last_Name) AS Salesperson_Name, SB.First_Name, SB.Last_Name, C.Street_Address AS Subscriber_Address
FROM Staff SP
JOIN Company C ON SP.Staff_ID = C.Staff_ID
JOIN Subscriber SB ON C.Company_ID = SB.Company_ID;

--Query D

SELECT Sensor_ID, Longitude_Latitude
FROM [3D_Sensor];

--Query G

/*
Input the ID of the sensor that the supplier list will be returned from. 
Provides supplier names and part names associated with the specified 3D sensor.
*/
-- Retrieve the list of suppliers for a given 3D sensor ID
DECLARE @SensorID INT = 3;

SELECT S.Supplier_Name, P.Name
FROM Supplier S
INNER JOIN Parts P ON S.Parts_ID = P.Part_ID
INNER JOIN [3D_Sensor_Supplier] SS ON SS.Supplier_ID = S.Supplier_ID
INNER JOIN [3D_Sensor] DS ON DS.Sensor_ID = SS.Sensor_ID
WHERE DS.Sensor_ID = @SensorID;

--Query I

/*
Specify the contract ID that should be deleted. The contract ID will be deleted from the corrosponding specified tables,
in this case from the `owns` and `video` tables, and it will delete the contract record from the contract table as well.
*/
SELECT Contract_ID
FROM Contract;

DECLARE @ContractID INT = 2;

DELETE FROM Recieves
WHERE Contract_ID = @ContractID;

DELETE FROM Owns
WHERE Contract_ID = @ContractID;

DELETE FROM Contract
WHERE Contract_ID = @ContractID;

--Query J

/*
Insert the sensor value of the sensor you want to get
the part costs from the maintenance records.
*/
SELECT Sensor_ID
FROM [3D_Sensor]

DECLARE @SensorID INT = 1; 

SELECT S.Sensor_ID, SUM(P.Cost) AS Total_Cost
FROM Maintenance_Records M
JOIN Parts P ON M.Part_Repaired = P.Name
JOIN [3D_Sensor] S ON M.Sensor_ID = S.Sensor_ID
WHERE S.Sensor_ID = @SensorID
GROUP BY S.Sensor_ID;








