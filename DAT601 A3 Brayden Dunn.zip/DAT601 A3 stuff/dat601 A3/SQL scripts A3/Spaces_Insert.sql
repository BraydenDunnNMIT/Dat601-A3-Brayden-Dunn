/*
Brayden Dunn Dat601 `Spaces` insertion script
*/

USE master;
USE Spaces_DDL;

-- Disable the foreign key constraints
EXEC sp_MSforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'

--Staff
INSERT INTO Staff (Position, First_Name, Last_Name, Phone)
VALUES ('Manager', 'John', 'Doe', 1234567890),
       ('Assistant', 'Jane', 'Smith', 9876543210),
       ('Supervisor', 'Michael', 'Johnson', 5678901234),
       ('Clerk', 'Emily', 'Williams', 4567890123),
       ('Technician', 'David', 'Brown', 7890123456),
       ('Receptionist', 'Sarah', 'Taylor', 2345678901),
       ('Accountant', 'Christopher', 'Anderson', 9012345678),
       ('Security Guard', 'Jessica', 'Thomas', 3456789012),
       ('Janitor', 'Matthew', 'Martinez', 6789012345),
       ('HR Manager', 'Olivia', 'Hernandez', 8901234567);
   
-- Company
INSERT INTO Company (Staff_ID, Street_Address, Name, Branch, Post_Code, City)
VALUES (1, '123 Main St', 'ABC Company', 'Branch A', '12345', 'New York'),
       (2, '456 Elm St', 'XYZ Inc.', 'Branch B', '54321', 'Los Angeles'),
       (3, '789 Oak St', '123 Corporation', 'Branch C', '67890', 'Chicago'),
       (4, '321 Pine St', 'ABC Company', 'Branch D', '98765', 'Houston'),
       (5, '654 Maple St', 'XYZ Inc.', 'Branch E', '56789', 'Miami'),
       (6, '987 Cedar St', '123 Corporation', 'Branch F', '43210', 'Seattle'),
       (7, '234 Walnut St', 'ABC Company', 'Branch G', '10987', 'San Francisco'),
       (8, '567 Birch St', 'XYZ Inc.', 'Branch H', '87654', 'Boston'),
       (9, '890 Ash St', '123 Corporation', 'Branch I', '21098', 'Denver'),
       (10, '432 Spruce St', 'ABC Company', 'Branch J', '76543', 'Dallas');

-- Subscriber
INSERT INTO Subscriber (Account_ID, Company_ID, First_Name, Last_Name, [D.O.B], Creation_Date)
VALUES (1, 1, 'John', 'Doe', '1990-01-01', '2023-01-01'),
       (2, 2, 'Jane', 'Smith', '1995-02-02', '2023-02-02'),
       (3, 3, 'Michael', 'Johnson', '1985-03-03', '2023-03-03'),
       (4, 4, 'Emily', 'Williams', '1992-04-04', '2023-04-04'),
       (5, 5, 'David', 'Brown', '1998-05-05', '2023-05-05'),
       (6, 6, 'Sarah', 'Taylor', '1993-06-06', '2023-06-06'),
       (7, 7, 'Christopher', 'Anderson', '1987-07-07', '2023-07-07'),
       (8, 8, 'Jessica', 'Thomas', '1996-08-08', '2023-08-08'),
       (9, 9, 'Matthew', 'Martinez', '1991-09-09', '2023-09-09'),
       (10, 10, 'Olivia', 'Hernandez', '1989-10-10', '2023-10-10');

-- Account
INSERT INTO Account (Payment_ID, Contract_ID, Username, Password, Registration_Date)
VALUES (1, 1, 'johndoe', 'password1', '2023-01-01'),
       (2, 2, 'janesmith', 'password2', '2023-02-02'),
       (3, 3, 'michaeljohnson', 'password3', '2023-03-03'),
       (4, 4, 'emilywilliams', 'password4', '2023-04-04'),
       (5, 5, 'davidbrown', 'password5', '2023-05-05'),
       (6, 6, 'sarahtaylor', 'password6', '2023-06-06'),
       (7, 7, 'chrisanderson', 'password7', '2023-07-07'),
       (8, 8, 'jessicathomas', 'password8', '2023-08-08'),
       (9, 9, 'matthewmartinez', 'password9', '2023-09-09'),
       (10, 10, 'oliviahernandez', 'password10', '2023-10-10');

-- Payment_Details
INSERT INTO Payment_Details (Purchase_Date, Card_Info, Amount_Charged, Discount_Modifier)
VALUES ('2023-01-01', '1234567890123456', 100.0, 0.1),
       ('2023-02-02', '9876543210987654', 200.0, 0.2),
       ('2023-03-03', '2468135790246813', 300.0, 0.3),
       ('2023-04-04', '1357924680135792', 400.0, 0.4),
       ('2023-05-05', '8642097531864209', 500.0, 0.5),
       ('2023-06-06', '7531864209753186', 600.0, 0.6),
       ('2023-07-07', '6420975318642097', 700.0, 0.7),
       ('2023-08-08', '5318642097531864', 800.0, 0.8),
       ('2023-09-09', '4209753186420975', 900.0, 0.9),
       ('2023-10-10', '3097531865318642', 1000.0, 1.0);

-- Contract
INSERT INTO Contract (Subscription_ID, Creation_Date, Contract_Description, AdministratorAdmin_ID)
VALUES (1, '2023-01-01', 'Contract 1', 1),
       (2, '2023-02-02', 'Contract 2', 2),
       (3, '2023-03-03', 'Contract 3', 3),
       (4, '2023-04-04', 'Contract 4', 4),
       (5, '2023-05-05', 'Contract 5', 5),
       (6, '2023-06-06', 'Contract 6', 6),
       (7, '2023-07-07', 'Contract 7', 7),
       (8, '2023-08-08', 'Contract 8', 8),
       (9, '2023-09-09', 'Contract 9', 9),
       (10, '2023-10-10', 'Contract 10', 10);

-- Standard_Subscription
INSERT INTO Standard_Subscription (GoldTier_ID, Zone_ID, Tier_ID, Salesperson_ID, Subscription_Length_ID, Subscription_Cost)
VALUES (1, 1, 1, 1, 1, 100.0),
       (2, 2, 2, 2, 2, 200.0),
       (3, 3, 3, 3, 3, 300.0),
       (4, 4, 4, 4, 4, 400.0),
       (5, 5, 5, 5, 5, 500.0),
       (6, 6, 6, 6, 6, 600.0),
       (7, 7, 7, 7, 7, 700.0),
       (8, 8, 8, 8, 8, 800.0),
       (9, 9, 9, 9, 9, 900.0),
       (10, 10, 10, 10, 10, 1000.0);

-- Tier
INSERT INTO Tier (Tier_Type)
VALUES ('Standard'),
       ('Gold'),
       ('Platinum'),
       ('Super_Platinum');
      

-- Zone
INSERT INTO Zone (Sensor_ID, Name, [Sensor#], Longitude_Latitude, Zone_Size)
VALUES (1, 'Zone 1', 1.1, '12.3456, -78.9012', 'Small'),
       (2, 'Zone 2', 2.2, '23.4567, -89.0123', 'Medium'),
       (3, 'Zone 3', 3.3, '34.5678, -90.1234', 'Large'),
       (4, 'Zone 4', 4.4, '45.6789, -01.2345', 'Small'),
       (5, 'Zone 5', 5.5, '56.7890, -12.3456', 'Medium'),
       (6, 'Zone 6', 6.6, '67.8901, -23.4567', 'Large'),
       (7, 'Zone 7', 7.7, '78.9012, -34.5678', 'Small'),
       (8, 'Zone 8', 8.8, '89.0123, -45.6789', 'Medium'),
       (9, 'Zone 9', 9.9, '90.1234, -56.7890', 'Large'),
       (10, 'Zone 10', 10.10, '01.2345, -67.8901', 'Small');

-- [3D_Sensor]
INSERT INTO [3D_Sensor] (Data_ID, Longitude_Latitude, Region, Sensor_Description, Last_Service_Date)
VALUES (1, '12.3456, -78.9012', 'Region 1', 'Sensor 1', '2023-01-01'),
       (2, '23.4567, -89.0123', 'Region 2', 'Sensor 2', '2023-02-02'),
       (3, '34.5678, -90.1234', 'Region 3', 'Sensor 3', '2023-03-03'),
       (4, '45.6789, -01.2345', 'Region 4', 'Sensor 4', '2023-04-04'),
       (5, '56.7890, -12.3456', 'Region 5', 'Sensor 5', '2023-05-05'),
       (6, '67.8901, -23.4567', 'Region 6', 'Sensor 6', '2023-06-06'),
       (7, '78.9012, -34.5678', 'Region 7', 'Sensor 7', '2023-07-07'),
       (8, '89.0123, -45.6789', 'Region 8', 'Sensor 8', '2023-08-08'),
       (9, '90.1234, -56.7890', 'Region 9', 'Sensor 9', '2023-09-09'),
       (10, '01.2345, -67.8901', 'Region 10', 'Sensor 10', '2023-10-10');


	   -- Enable the foreign key constraints
EXEC sp_MSforeachtable 'ALTER TABLE ? WITH CHECK CHECK CONSTRAINT ALL'

	   /* Testing if inserted data is present */

	   --testing DDL script
select * from subscriber;
select * from Account;
select * from staff;
select * from company; 
select * from [3D_Sensor];
